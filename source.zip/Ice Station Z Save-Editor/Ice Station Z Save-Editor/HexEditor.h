void HexEdit(char inputv[10]);

int HexLetterEdit(char vl[5], char vl2[5], char vl3[5], char vl4[5], char DataValue[6], char vl5[5], char vl6[5], char vl7[5], char vl8[5]);